var users = [
  {
    id: 1,
    name: "John",
    age: 25,
    sex: "masculino",
    weight: 70,
    height: 175,
    activityLevel: "moderado",
    goal: "manter",
  },
  {
    id: 2,
    name: "Maria",
    age: 30,
    sex: "feminino",
    weight: 60,
    height: 165,
    activityLevel: "leve",
    goal: "perder",
  },
];

export default users;
